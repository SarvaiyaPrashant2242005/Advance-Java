package com.prashantsarvaiya.firstpro;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FirstproApplication {

	public static void main(String[] args) {
		SpringApplication.run(FirstproApplication.class, args);
	}

}
