package com.prashantsarvaiya.firstpro;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FirstproApplicationTests {

	@Test
	void contextLoads() {
	}

}
