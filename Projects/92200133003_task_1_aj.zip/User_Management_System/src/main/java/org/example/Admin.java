package org.example;

public class Admin {
}
